-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 03:10 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `UserName` varchar(32) NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`UserName`, `Password`, `Status`) VALUES
('admin', 'admin', 2),
('mehedy', '54321', 1),
('mehedy123', '54321', 0),
('samia', '12345', 1),
('samia123', '12345', 0),
('sohan', '123', 1),
('sohan123', '123', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Name` varchar(100) NOT NULL,
  `UserNamefk` varchar(32) NOT NULL,
  `Contact_no` varchar(20) NOT NULL,
  `SchoolOrCollege` varchar(100) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Medium` varchar(32) NOT NULL,
  `Class` varchar(32) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Unverified'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Name`, `UserNamefk`, `Contact_no`, `SchoolOrCollege`, `Location`, `Medium`, `Class`, `Gender`, `status`) VALUES
('Yasmin Samia', 'samia123', '01819181702', 'VNSC', 'Bashundhara', 'English', 'Five', 'Female', 'Unverified'),
('Hasan Mehedy', 'mehedy123', '01912345678', 'Rajuk', 'Khilkhet', 'Bangla', 'Twelve', 'Male', 'Unverified'),
('Sohan Faruk Abdullah', 'sohan123', '018234566789', 'NDC', 'Dhanmondi', 'English', 'Eleven', 'Male', 'Unverified');

-- --------------------------------------------------------

--
-- Table structure for table `studentrequest`
--

CREATE TABLE `studentrequest` (
  `UserName` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `ContactNo` varchar(100) NOT NULL,
  `SchoolCollege` varchar(100) NOT NULL,
  `Medium` varchar(100) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Class` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

CREATE TABLE `tutor` (
  `Name` varchar(32) NOT NULL,
  `UserNametk` varchar(32) NOT NULL,
  `Contact_No` varchar(32) NOT NULL,
  `Current_Edu_Status` varchar(32) NOT NULL,
  `Location` varchar(32) NOT NULL,
  `Experience` varchar(32) NOT NULL,
  `Salary_Range` varchar(32) NOT NULL,
  `Medium` varchar(32) NOT NULL,
  `Gender` varchar(32) NOT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'Unverified'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor`
--

INSERT INTO `tutor` (`Name`, `UserNametk`, `Contact_No`, `Current_Edu_Status`, `Location`, `Experience`, `Salary_Range`, `Medium`, `Gender`, `status`) VALUES
('Samia Yasmin', 'samia', '01911538983', 'CSE,AIUB', 'Dhanmondi', '< 2 Years', '< 5,000', 'English', 'Female', 'Unverified'),
('Mehedy Hasan', 'mehedy', '01997965586', 'CS,MIST', 'kallyanpur', '< 3 Years', '< 15,000', 'Bangla', 'Male', 'Unverified'),
('Md Faruk Abdullah Al Sohan', 'sohan', '01777699321', 'EEE,BUET', 'Dhanmondi', '< 6 Months', '< 5,000', 'Bangla', 'Male', 'Unverified');

-- --------------------------------------------------------

--
-- Table structure for table `tutorrequest`
--

CREATE TABLE `tutorrequest` (
  `UserName` varchar(32) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `ContactNo` varchar(32) NOT NULL,
  `Location` varchar(32) NOT NULL,
  `Current_Edu_Status` varchar(32) NOT NULL,
  `Experience` varchar(32) NOT NULL,
  `SalaryRange` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`UserName`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD KEY `UserNamefk` (`UserNamefk`);

--
-- Indexes for table `tutor`
--
ALTER TABLE `tutor`
  ADD KEY `UserName` (`UserNametk`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`UserNamefk`) REFERENCES `login` (`UserName`);

--
-- Constraints for table `tutor`
--
ALTER TABLE `tutor`
  ADD CONSTRAINT `tutor_ibfk_1` FOREIGN KEY (`UserNametk`) REFERENCES `login` (`UserName`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
