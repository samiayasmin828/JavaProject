package javaprojectfinal;

public class MainClass {

    public static void main(String[] args) {
       
        Welcome w1 = new Welcome();
        w1.setVisible(true);
        
    }
}
